namespace QuanLyRapChieuPhim;

public class MovieForm : Form
{
    readonly DataGridView grid=Ui.Grid();
    readonly TextBox id=Ui.Box(100),title=Ui.Box(180),genre=Ui.Box(130),duration=Ui.Box(80),poster=Ui.Box(220);
    readonly PictureBox preview=new(){Width=100,Height=125,SizeMode=PictureBoxSizeMode.Zoom,BorderStyle=BorderStyle.FixedSingle,BackColor=Color.White};
    readonly ListView list=new(){Dock=DockStyle.Right,Width=170,View=View.LargeIcon,LargeImageList=new ImageList{ImageSize=new Size(64,80),ColorDepth=ColorDepth.Depth32Bit},BackColor=Color.White,ForeColor=Ui.MainText};
    public MovieForm()
    {
        Text="Quản lý phim"; Width=1050; Height=650; StartPosition=FormStartPosition.CenterScreen; BackColor=Ui.MainBack;
        var top=new Panel{Dock=DockStyle.Top,Height=205,BackColor=Ui.MainBack,Padding=new Padding(10)};
        var fields=new FlowLayoutPanel{Dock=DockStyle.Top,Height=80,AutoSize=false,WrapContents=true,BackColor=Ui.MainBack};
        AddField(fields,"Mã phim",id);AddField(fields,"Tên phim",title);AddField(fields,"Thể loại",genre);AddField(fields,"Thời lượng (phút)",duration);
        var posterRow=new FlowLayoutPanel{Dock=DockStyle.Top,Height=42,WrapContents=false,BackColor=Ui.MainBack};
        poster.Width=300; AddField(posterRow,"Đường dẫn poster",poster);
        var pick=Ui.Btn("Chọn poster");pick.Click+=(_,_)=>PickPoster();posterRow.Controls.Add(pick);
        var buttons=new FlowLayoutPanel{Dock=DockStyle.Top,Height=48,WrapContents=true,BackColor=Ui.MainBack};
        foreach(var text in new[]{"Thêm","Sửa","Xóa","Nhập CSV","Lọc thể loại","Làm mới"})
        { var b=Ui.Btn(text);b.Click+=(_,_)=>Action(text);buttons.Controls.Add(b); }
        top.Controls.Add(buttons);top.Controls.Add(posterRow);top.Controls.Add(fields);
        var content=new Panel{Dock=DockStyle.Fill,BackColor=Color.White,Padding=new Padding(10)};
        content.Controls.Add(grid);content.Controls.Add(list);
        Controls.Add(content);Controls.Add(top);
        RefreshData();
        grid.SelectionChanged+=(_,_)=>LoadSelected();
        list.ItemActivate+=(_,_)=>{if(list.SelectedIndices.Count>0){var idx=list.SelectedIndices[0];if(idx<AppData.Movies.Count){var m=AppData.Movies[idx];id.Text=m.Id;title.Text=m.Title;genre.Text=m.Genre;duration.Text=m.DurationMinutes.ToString();poster.Text=m.PosterPath;}}};
    }
    static void AddField(FlowLayoutPanel p,string label,Control c){var wrap=new Panel{Width=c.Width+8,Height=62,BackColor=Ui.MainBack};var l=Ui.Lab(label);l.Location=new Point(0,0);var input=new Panel{Location=new Point(0,24),Width=c.Width+5,Height=30,BackColor=Ui.MainBack};c.Location=new Point(0,0);input.Controls.Add(c);wrap.Controls.Add(l);wrap.Controls.Add(input);p.Controls.Add(wrap);}
    void PickPoster(){using var d=new OpenFileDialog{Filter="Ảnh|*.png;*.jpg;*.jpeg;*.bmp"};if(d.ShowDialog()==DialogResult.OK){poster.Text=d.FileName;try{using var fs=new FileStream(d.FileName,FileMode.Open,FileAccess.Read);preview.Image=Image.FromStream(fs);}catch(Exception ex){Ui.ShowError(ex);}}}
    void Action(string action)
    {
        try
        {
            if(action=="Thêm"){if(string.IsNullOrWhiteSpace(id.Text)||string.IsNullOrWhiteSpace(title.Text))throw new Exception("Nhập mã và tên phim.");if(AppData.Movies.Any(x=>x.Id==id.Text.Trim()))throw new Exception("Mã phim đã tồn tại.");AppData.Movies.Add(ReadInput());}
            else if(action=="Sửa"){var m=AppData.Movies.FirstOrDefault(x=>x.Id==id.Text.Trim())??throw new Exception("Không tìm thấy phim.");var n=ReadInput();m.Title=n.Title;m.Genre=n.Genre;m.DurationMinutes=n.DurationMinutes;m.PosterPath=n.PosterPath;}
            else if(action=="Xóa"){var m=AppData.Movies.FirstOrDefault(x=>x.Id==id.Text.Trim())??throw new Exception("Chọn phim cần xóa.");if(AppData.Screenings.Any(s=>s.MovieId==m.Id))throw new Exception("Phim đã có suất chiếu, không thể xóa.");AppData.Movies.Remove(m);}
            else if(action=="Nhập CSV"){using var d=new OpenFileDialog{Filter="CSV|*.csv"};if(d.ShowDialog()!=DialogResult.OK)return;foreach(var line in File.ReadAllLines(d.FileName).Skip(1)){var p=line.Split(',');if(p.Length>=4&&!AppData.Movies.Any(m=>m.Id==p[0].Trim()))AppData.Movies.Add(new Movie{Id=p[0].Trim(),Title=p[1].Trim(),Genre=p[2].Trim(),DurationMinutes=int.Parse(p[3])});}}
            else if(action=="Lọc thể loại"){var g=Microsoft.VisualBasic.Interaction.InputBox("Nhập thể loại cần lọc:","Lọc phim");grid.DataSource=AppData.Movies.Where(x=>x.Genre.Contains(g,StringComparison.OrdinalIgnoreCase)).Select(x=>new{x.Id,x.Title,x.Genre,x.DurationMinutes}).ToList();return;}
            else if(action=="Làm mới"){id.Clear();title.Clear();genre.Clear();duration.Clear();poster.Clear();}
            AppData.SaveMovies();RefreshData();
        }catch(Exception ex){Ui.ShowError(ex);}
    }
    Movie ReadInput()=>new(){Id=id.Text.Trim(),Title=title.Text.Trim(),Genre=genre.Text.Trim(),DurationMinutes=int.TryParse(duration.Text,out var n)&&n>0?n:throw new Exception("Thời lượng phải là số phút dương."),PosterPath=poster.Text.Trim()};
    void RefreshData(){grid.DataSource=AppData.Movies.Select(x=>new{x.Id,x.Title,x.Genre,x.DurationMinutes}).ToList();list.Items.Clear();list.LargeImageList!.Images.Clear();foreach(var m in AppData.Movies){try{if(File.Exists(m.PosterPath)){using var fs=new FileStream(m.PosterPath,FileMode.Open,FileAccess.Read);list.LargeImageList.Images.Add(Image.FromStream(fs));}else list.LargeImageList.Images.Add(new Bitmap(64,80));}catch{list.LargeImageList.Images.Add(new Bitmap(64,80));}list.Items.Add(new ListViewItem(m.Title,list.LargeImageList.Images.Count-1));}}
    void LoadSelected(){if(grid.CurrentRow==null)return;var key=grid.CurrentRow.Cells["Id"]?.Value?.ToString();var m=AppData.Movies.FirstOrDefault(x=>x.Id==key);if(m==null)return;id.Text=m.Id;title.Text=m.Title;genre.Text=m.Genre;duration.Text=m.DurationMinutes.ToString();poster.Text=m.PosterPath;try{if(File.Exists(m.PosterPath)){using var fs=new FileStream(m.PosterPath,FileMode.Open,FileAccess.Read);preview.Image=Image.FromStream(fs);}else preview.Image=null;}catch{preview.Image=null;}}
}
