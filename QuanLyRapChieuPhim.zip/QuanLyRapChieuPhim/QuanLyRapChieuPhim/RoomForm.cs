namespace QuanLyRapChieuPhim;

public class RoomForm : Form
{
    readonly DataGridView grid=Ui.Grid();readonly TextBox id=Ui.Box(90),name=Ui.Box(160),rows=Ui.Box(60),seats=Ui.Box(60),vip=Ui.Box(60);
    public RoomForm(){BackColor=Ui.MainBack;ForeColor=Ui.MainText;Font=new Font("Segoe UI",9);Text="Quản lý phòng chiếu";Width=800;Height=500;var p=Ui.Flow();Add(p,"Mã",id);Add(p,"Tên phòng",name);Add(p,"Số hàng",rows);Add(p,"Ghế/hàng",seats);Add(p,"Hàng VIP",vip);foreach(var s in new[]{"Thêm","Sửa","Xóa"}){var b=Ui.Btn(s);b.Click+=(_,_)=>Act(s);p.Controls.Add(b);}Controls.Add(grid);Controls.Add(p);grid.SelectionChanged+=(_,_)=>LoadSelected();RefreshGrid();}
    static void Add(FlowLayoutPanel p,string t,Control c){p.Controls.Add(Ui.Lab(t));p.Controls.Add(c);}
    void Act(string a){try{if(a=="Thêm"){if(AppData.Rooms.Any(x=>x.Id==id.Text.Trim()))throw new Exception("Mã phòng đã tồn tại.");AppData.Rooms.Add(Read());}else if(a=="Sửa"){var r=AppData.Rooms.FirstOrDefault(x=>x.Id==id.Text.Trim())??throw new Exception("Không tìm thấy phòng.");var n=Read();r.Name=n.Name;r.Rows=n.Rows;r.SeatsPerRow=n.SeatsPerRow;r.VipRows=n.VipRows;}else{var r=AppData.Rooms.FirstOrDefault(x=>x.Id==id.Text.Trim())??throw new Exception("Chọn phòng cần xóa.");if(AppData.Screenings.Any(x=>x.RoomId==r.Id))throw new Exception("Phòng đã có suất chiếu.");AppData.Rooms.Remove(r);}AppData.SaveRooms();RefreshGrid();}catch(Exception ex){Ui.ShowError(ex);}}
    CinemaRoom Read(){int Parse(TextBox t)=>int.TryParse(t.Text,out var n)&&n>0?n:throw new Exception("Số hàng, ghế và hàng VIP phải là số dương.");var rr=Parse(rows);var ss=Parse(seats);if(!int.TryParse(vip.Text,out var vv)||vv<0||vv>rr)throw new Exception("Hàng VIP phải từ 0 đến số hàng.");if(string.IsNullOrWhiteSpace(id.Text)||string.IsNullOrWhiteSpace(name.Text))throw new Exception("Nhập mã và tên phòng.");return new(){Id=id.Text.Trim(),Name=name.Text.Trim(),Rows=rr,SeatsPerRow=ss,VipRows=vv};}
    void RefreshGrid()=>grid.DataSource=AppData.Rooms.Select(x=>new{x.Id,x.Name,x.Rows,x.SeatsPerRow,x.VipRows,x.Capacity}).ToList();
    void LoadSelected(){if(grid.CurrentRow==null)return;var r=AppData.Rooms.FirstOrDefault(x=>x.Id==grid.CurrentRow.Cells["Id"]?.Value?.ToString());if(r==null)return;id.Text=r.Id;name.Text=r.Name;rows.Text=r.Rows.ToString();seats.Text=r.SeatsPerRow.ToString();vip.Text=r.VipRows.ToString();}
}
