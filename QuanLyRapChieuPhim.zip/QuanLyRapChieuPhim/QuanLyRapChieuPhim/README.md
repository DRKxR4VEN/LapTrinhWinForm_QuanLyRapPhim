# Quản lý rạp chiếu phim - C# WinForms

## Yêu cầu
- Windows 10/11
- Visual Studio 2022 với workload **.NET desktop development**
- .NET 8 SDK

## Chạy chương trình
1. Giải nén thư mục.
2. Mở `QuanLyRapChieuPhim.csproj` bằng Visual Studio.
3. Chọn cấu hình `Debug`, nhấn F5.
4. Tài khoản mặc định:
   - Quản trị: `admin` / `123`
   - Nhân viên: `nhanvien` / `123`
5. Dữ liệu tự sinh trong thư mục `Data` cạnh file chạy lần đầu.

## Các chức năng
- Đăng nhập đọc `Data/users.txt`, khóa tài khoản sau 3 lần sai trong phiên chạy.
- Quản lý phim, chọn poster, lọc thể loại, nhập CSV.
- Quản lý phòng chiếu, số hàng/ghế và hàng VIP.
- Quản lý suất chiếu dạng cây Ngày -> Phim -> Suất; kiểm tra trùng lịch, cộng 15 phút dọn phòng; không hủy suất đã bán vé.
- Chọn ghế động, trạng thái ghế, ghế VIP giá cao hơn 50%, giảm giá theo `App.config`, in vé ra `.txt`.
- Báo cáo doanh thu theo phim và ngày.
- MDI, cấu hình giao diện lưu Registry, sao lưu/khôi phục dữ liệu, ghi lỗi vào `Data/log.txt`.

## Định dạng CSV nhập phim
Tạo file CSV với dòng đầu là tiêu đề, các dòng sau theo thứ tự:
`MaPhim,TenPhim,TheLoai,ThoiLuongPhut`
Ví dụ:
`P001,Lat Mat,Han dong,120`

Lưu ý: bản demo sử dụng dấu phẩy để tách cột; tên phim/thể loại không nên chứa dấu phẩy.

## Định dạng users.txt
Mỗi dòng: `username|password|role`
Ví dụ:
`admin|123|QuanTri`
`nhanvien|123|NhanVien`

