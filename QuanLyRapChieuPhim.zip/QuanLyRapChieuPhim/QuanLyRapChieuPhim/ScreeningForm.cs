namespace QuanLyRapChieuPhim;

public class ScreeningForm : Form
{
    readonly TreeView tree = new() { Dock = DockStyle.Fill };

    readonly ComboBox movie = new()
    {
        DropDownStyle = ComboBoxStyle.DropDownList,
        Width = 180
    };

    readonly ComboBox room = new()
    {
        DropDownStyle = ComboBoxStyle.DropDownList,
        Width = 140
    };

    readonly DateTimePicker start = new()
    {
        Format = DateTimePickerFormat.Custom,
        CustomFormat = "dd/MM/yyyy HH:mm",
        Width = 160
    };

    public ScreeningForm()
    {
        BackColor = Ui.MainBack;
        ForeColor = Ui.MainText;
        Font = new Font("Segoe UI", 9);
        Text = "Quản lý suất chiếu";
        Width = 850;
        Height = 550;

        var p = Ui.Flow();

        p.Controls.Add(Ui.Lab("Phim"));
        p.Controls.Add(movie);

        p.Controls.Add(Ui.Lab("Phòng"));
        p.Controls.Add(room);

        p.Controls.Add(Ui.Lab("Bắt đầu"));
        p.Controls.Add(start);

        var add = Ui.Btn("Thêm suất");
        add.Click += (_, _) => AddScreening();
        p.Controls.Add(add);

        var cancel = Ui.Btn("Hủy suất chọn");
        cancel.Click += (_, _) => CancelScreening();
        p.Controls.Add(cancel);

        Controls.Add(tree);
        Controls.Add(p);

        RefreshChoices();
        RefreshTree();
    }

    void RefreshChoices()
    {
        movie.DataSource = null;
        movie.DataSource = AppData.Movies.ToList();
        movie.DisplayMember = "Title";

        room.DataSource = null;
        room.DataSource = AppData.Rooms.ToList();
        room.DisplayMember = "Name";
    }

    void AddScreening()
    {
        try
        {
            if (movie.SelectedItem is not Movie m ||
                room.SelectedItem is not CinemaRoom r)
            {
                throw new Exception("Cần có phim và phòng chiếu trước.");
            }

            var s = new Screening
            {
                Id = "SC" + DateTime.Now.ToString("yyyyMMddHHmmssfff"),
                MovieId = m.Id,
                RoomId = r.Id,
                StartTime = start.Value,
                MovieTitle = m.Title,
                RoomName = r.Name
            };

            if (AppData.HasConflict(s, m))
            {
                throw new Exception(
                    "Trùng lịch phòng chiếu (đã tính cả 15 phút dọn phòng).");
            }

            AppData.Screenings.Add(s);
            AppData.SaveScreenings();
            RefreshTree();
        }
        catch (Exception ex)
        {
            Ui.ShowError(ex);
        }
    }

    void CancelScreening()
    {
        try
        {
            TreeNode? node = tree.SelectedNode;

            // Nếu chọn ngày hoặc phim, tìm suất chiếu bên dưới.
            while (node != null && node.Tag is not Screening)
            {
                if (node.Nodes.Count == 0)
                {
                    node = null;
                    break;
                }

                node = node.Nodes[0];
            }

            if (node?.Tag is not Screening s)
            {
                MessageBox.Show(
                    "Vui lòng chọn một suất chiếu có giờ và phòng.",
                    "Thông báo",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            // Không xóa suất chiếu đã có vé.
            if (AppData.HasSoldTickets(s.Id))
            {
                MessageBox.Show(
                    "Không thể hủy suất đã bán vé.",
                    "Thông báo",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            var result = MessageBox.Show(
                $"Bạn có chắc muốn hủy suất chiếu {s.MovieTitle} " +
                $"lúc {s.StartTime:HH:mm dd/MM/yyyy} tại {s.RoomName}?",
                "Xác nhận hủy suất chiếu",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (result != DialogResult.Yes)
                return;

            AppData.Screenings.Remove(s);
            AppData.SaveScreenings();

            RefreshTree();

            MessageBox.Show(
                "Hủy suất chiếu thành công!",
                "Thông báo",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }
        catch (Exception ex)
        {
            Ui.ShowError(ex);
        }
    }

    void RefreshTree()
    {
        tree.BeginUpdate();
        tree.Nodes.Clear();

        foreach (var day in AppData.Screenings
                     .OrderBy(x => x.StartTime)
                     .GroupBy(x => x.StartTime.Date))
        {
            var dayNode = tree.Nodes.Add(
                day.Key.ToString("dd/MM/yyyy"));

            foreach (var group in day.GroupBy(x => x.MovieTitle))
            {
                var movieNode = dayNode.Nodes.Add(group.Key);

                foreach (var s in group.OrderBy(x => x.StartTime))
                {
                    var screeningNode = movieNode.Nodes.Add(
                        $"{s.StartTime:HH:mm} - {s.RoomName}");

                    screeningNode.Tag = s;
                }
            }
        }

        tree.ExpandAll();
        tree.EndUpdate();
    }
}